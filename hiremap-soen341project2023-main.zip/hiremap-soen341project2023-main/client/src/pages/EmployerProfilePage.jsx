import React, { Component } from "react";
import { Container } from "react-bootstrap";
import EmployerProfile from "../components/EmployerProfile/EmployerProfile";

const EmployerProfilePage = () => {

    return (
        <div>
            <EmployerProfile/>
        </div>
    );
}

export default EmployerProfilePage;