import React, { Component } from "react";
import { Container } from "react-bootstrap";
import EmployerSignUp from "../components/EmployerSignUp/EmployerSignUp";
const SignUpEmployer = () => {
    return (
        <div>
            <EmployerSignUp/>
        </div>
    );
}

export default SignUpEmployer;