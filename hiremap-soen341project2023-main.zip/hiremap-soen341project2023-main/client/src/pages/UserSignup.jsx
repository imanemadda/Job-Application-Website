import React, { Component } from "react";
import { Container } from "react-bootstrap";
import UserSignUp from "../components/UserSignUp/UserSignUp";
const SignUpUser = () => {
    return (
        <div>
            <UserSignUp/>
        </div>
    );
}

export default SignUpUser;