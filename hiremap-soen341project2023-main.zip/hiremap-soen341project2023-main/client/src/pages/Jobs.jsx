import React, { Component } from "react";
import { Container } from "react-bootstrap";
import JobsPage from "../components/JobsPage/JobsPage.js";



const Jobs = () => {
    
    return (
        <div>
            {/* <h1>Jobs Page</h1> */}
            
            <JobsPage/>
            
        </div>
    );
}

export default Jobs;