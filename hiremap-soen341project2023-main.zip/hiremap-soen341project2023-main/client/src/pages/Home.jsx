import React from "react";
import { Container } from "react-bootstrap";
import HomeContent from "../components/HomeContent/HomeContent";

const Home = () => {
    return (
        <div>
            <HomeContent />
        </div>
    );
}

export default Home;