import React, { Component } from "react";
import { Container } from "react-bootstrap";
import EmployerLogin from "../components/EmployerLogin/EmployerLogin";
const LoginEmployer = () => {
    return (
        <div>
            <EmployerLogin/>
        </div>
    );
}

export default LoginEmployer;