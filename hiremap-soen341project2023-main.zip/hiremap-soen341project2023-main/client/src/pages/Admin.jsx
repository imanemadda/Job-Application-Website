import React from "react";
import AdminPage from "../components/AdminPage/AdminPage.js";

const Admin = () => {
    return (
        <div>
            <AdminPage/>
        </div>
    );
}

export default Admin;