import React, { Component } from "react";
import { Container } from "react-bootstrap";

const Login = () => {
    return (
        <Container>
            <h1>Login Page</h1>
        </Container>
    );
}

export default Login;