import React, { Component } from "react";
import { Container } from "react-bootstrap";
import UserLogin from "../components/UserLogin/UserLogin";
const LoginUser = () => {
    return (
        <div>
            <UserLogin/>
        </div>
    );
}

export default LoginUser;