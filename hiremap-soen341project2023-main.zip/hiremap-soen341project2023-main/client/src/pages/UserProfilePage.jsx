import React, { Component } from "react";
import { Container } from "react-bootstrap";
import UserProfile from "../components/UserProfile/UserProfile";

const UserProfilePage = () => {

    return (
        <div>
            <UserProfile />
        </div>
    );
}

export default UserProfilePage;