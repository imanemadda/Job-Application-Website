import React from "react";

import EmployerSignUp from "../EmployerSignUp.js";

export default function EmployerSignUpForm() {
  return (
    <section>
      <div className="EmployerSignUpForm">
        <header className="EmployerSignUpForm-header">
          <Search />
        </header>
      </div>
    </section>
  );
}
