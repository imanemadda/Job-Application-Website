import React from "react";


import UserSignUp from "../UserSignUp.js";

export default function UserSignUp() {
  return (
    <section>
      <div className="UserSignUpForm">
        <header className="UserSignUpForm-header">
          <Search />
        </header>
      </div>
    </section>
    
  );
}