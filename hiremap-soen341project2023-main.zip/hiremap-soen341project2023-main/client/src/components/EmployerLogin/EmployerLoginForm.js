import React from "react";

import EmployerLogin from "./EmployerLogin.js";

export default function EmployerLoginForm() {
  return (
    <section>
      <div className="EmployerLoginForm">
        <header className="EmployerLoginForm-header">
          <Search />
        </header>
      </div>
    </section>
  );
}
