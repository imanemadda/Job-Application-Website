import React from "react";


import UserLogin from "../UserLogin.js";

export default function EmployerLogin() {
  return (
    <section>
      <div className="UserLoginForm">
        <header className="UserLoginForm-header">
          <Search />
        </header>
      </div>
    </section>
    
  );
}